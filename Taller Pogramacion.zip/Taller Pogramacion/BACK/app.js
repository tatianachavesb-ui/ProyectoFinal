const path = require('path');
const express = require('express');
const cors = require('cors');
const mysql = require('mysql');
const app = express();

app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname)));

const PORT = 5000;

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'TallerProgramacion'
});

db.connect((err) => {
  if (err) {
    console.log('Error de conexion a base de datos');
  } else {
    console.log('Conectado a la base de datos');
  }
});

app.get('/registro', (req, res) => {
  res.sendFile(path.join(__dirname, 'registro.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'login.html'));
});

app.get('/inicio', (req, res) => {
  res.sendFile(path.join(__dirname, 'inicio.html'));
});

app.post('/registro', (req, res) => {
  const { Nombre, correo, Usuario, Contraseña, Telefono, Ciudad } = req.body;

  const query = 'INSERT INTO Usuario (Nombre, Correo, Usuario, Contraseña, Telefono, Ciudad) VALUES (?, ?, ?, ?, ?, ?)';
  
  db.query(query, [Nombre, correo, Usuario, Contraseña, Telefono, Ciudad], (err, result) => {
    if (err) {
      console.log(err);
      res.status(500).json({ mensaje: 'Error en el registro' });
    } else {
      res.status(201).json({ mensaje: 'Usuario registrado correctamente' });
    }
  });
});

app.post('/login', (req, res) => {
  const { Usuario, Contraseña } = req.body;

  const query = 'SELECT * FROM Usuario WHERE Usuario = ? AND Contraseña = ?';
  
  db.query(query, [Usuario, Contraseña], (err, result) => {
    if (err) {
      console.log(err);
      res.status(500).json({ mensaje: 'Error en el servidor' });
    } else {
      if (result.length > 0) {
        res.status(200).json({ 
          mensaje: 'Usuario encontrado', 
          usuario: result[0] 
        });
      } else {
        res.status(404).json({ 
          mensaje: 'Usuario no registrado' 
        });
      }
    }
  });
});

app.listen(PORT, () => {
  console.log('Servidor escuchando en puerto ' + PORT);
});